package com.central.app.tools.bmi

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.central.app.core.Tool
import com.central.app.ui.NumField
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import com.central.app.ui.fmt
import com.central.app.ui.toNum

object BmiTool : Tool {
    override val id = "bmi"
    override val title = "IMC"
    override val description = "Índice de massa corporal."
    override val emoji = "⚖️"

    @Composable
    override fun Content() {
        var weight by remember { mutableStateOf("") }
        var height by remember { mutableStateOf("") }

        val w = weight.toNum()
        val h = height.toNum()

        ToolPage {
            NumField(weight, { weight = it }, "Peso (kg)")
            NumField(height, { height = it }, "Altura (cm)")
            if (w != null && h != null && h > 0.0 && w > 0.0) {
                val meters = h / 100.0
                val bmi = w / (meters * meters)
                val category = when {
                    bmi < 18.5 -> "Abaixo do peso"
                    bmi < 25.0 -> "Peso normal"
                    bmi < 30.0 -> "Sobrepeso"
                    bmi < 35.0 -> "Obesidade grau I"
                    bmi < 40.0 -> "Obesidade grau II"
                    else -> "Obesidade grau III"
                }
                ResultCard("IMC ${fmt(bmi, 1)}: $category")
                ResultCard(
                    "Referência geral da OMS para adultos. Não substitui avaliação de um profissional de saúde.",
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}
