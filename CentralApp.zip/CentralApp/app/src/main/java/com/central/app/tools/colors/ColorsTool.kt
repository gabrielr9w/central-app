package com.central.app.tools.colors

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.central.app.core.Tool
import com.central.app.ui.Field
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage

private val HEX = Regex("^[0-9A-Fa-f]{6}$")

object ColorsTool : Tool {
    override val id = "colors"
    override val title = "Cores"
    override val description = "Misture RGB ou digite o código HEX."
    override val emoji = "🎨"

    @Composable
    override fun Content() {
        var hex by remember { mutableStateOf("3F51B5") }

        val valid = HEX.matches(hex)
        val r = if (valid) hex.substring(0, 2).toInt(16) else 0
        val g = if (valid) hex.substring(2, 4).toInt(16) else 0
        val b = if (valid) hex.substring(4, 6).toInt(16) else 0

        fun set(nr: Int, ng: Int, nb: Int) {
            hex = String.format("%02X%02X%02X", nr, ng, nb)
        }

        ToolPage {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .background(Color(r, g, b)),
            )
            Field(hex, { hex = it.removePrefix("#").uppercase().take(6) }, "HEX (6 dígitos, sem #)")
            Text("Vermelho: $r")
            Slider(value = r.toFloat(), onValueChange = { set(it.toInt(), g, b) }, valueRange = 0f..255f)
            Text("Verde: $g")
            Slider(value = g.toFloat(), onValueChange = { set(r, it.toInt(), b) }, valueRange = 0f..255f)
            Text("Azul: $b")
            Slider(value = b.toFloat(), onValueChange = { set(r, g, it.toInt()) }, valueRange = 0f..255f)
            if (valid) {
                ResultCard(
                    "#${hex.uppercase()}\nrgb($r, $g, $b)",
                    copyable = true,
                    style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}
