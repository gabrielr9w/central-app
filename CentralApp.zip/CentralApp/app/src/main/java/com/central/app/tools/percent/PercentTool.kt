package com.central.app.tools.percent

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.central.app.core.Tool
import com.central.app.ui.Chooser
import com.central.app.ui.NumField
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import com.central.app.ui.fmt
import com.central.app.ui.toNum

object PercentTool : Tool {
    override val id = "percent"
    override val title = "Porcentagem"
    override val description = "Quanto é X% de Y, variação, desconto."
    override val emoji = "％"

    private val modes = listOf("X% de Y", "X é quantos % de Y", "Variação de X para Y", "Desconto / acréscimo")

    @Composable
    override fun Content() {
        var mode by remember { mutableIntStateOf(0) }
        var a by remember { mutableStateOf("") }
        var b by remember { mutableStateOf("") }

        val labelA = when (mode) {
            0 -> "X (porcentagem)"
            1 -> "X (valor)"
            2 -> "X (valor inicial)"
            else -> "Valor"
        }
        val labelB = when (mode) {
            0 -> "Y (valor)"
            1 -> "Y (total)"
            2 -> "Y (valor final)"
            else -> "Porcentagem"
        }

        val x = a.toNum()
        val y = b.toNum()

        ToolPage {
            Chooser(modes, mode) { mode = it }
            NumField(a, { a = it }, labelA)
            NumField(b, { b = it }, labelB)
            if (x != null && y != null) {
                when (mode) {
                    0 -> ResultCard("${fmt(x)}% de ${fmt(y)} = ${fmt(x * y / 100.0)}")
                    1 -> if (y != 0.0) ResultCard("${fmt(x)} é ${fmt(x / y * 100.0)}% de ${fmt(y)}")
                    2 -> if (x != 0.0) {
                        val v = (y - x) / x * 100.0
                        ResultCard((if (v >= 0) "Aumento de " else "Queda de ") + fmt(Math.abs(v)) + "%")
                    }
                    else -> {
                        ResultCard("Com desconto de ${fmt(y)}%: ${fmt(x - x * y / 100.0)}")
                        ResultCard("Com acréscimo de ${fmt(y)}%: ${fmt(x + x * y / 100.0)}")
                    }
                }
            }
        }
    }
}
