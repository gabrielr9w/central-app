package com.central.app.tools.video

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.net.URLDecoder

/** Entrega o download ao DownloadManager do Android (notificação + continua com o app fechado). */
object VideoDownloader {

    fun enqueue(context: Context, video: VideoCandidate, referer: String): Long {
        val name = fileNameFor(video)
        val request = DownloadManager.Request(Uri.parse(video.url))
            .setTitle(name)
            .setDescription("Baixando vídeo")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES, "Central/$name")
            .addRequestHeader("User-Agent", VideoExtractor.USER_AGENT)
            .addRequestHeader("Referer", referer)
            .setAllowedOverMetered(true)

        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return manager.enqueue(request)
    }

    private fun fileNameFor(video: VideoCandidate): String {
        val raw = video.url.toHttpUrlOrNull()?.pathSegments?.lastOrNull().orEmpty()
        val decoded = try {
            URLDecoder.decode(raw, "UTF-8")
        } catch (e: Exception) {
            raw
        }
        val clean = decoded.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
        val ext = if (video.type == "WEBM") "webm" else "mp4"
        return if (clean.contains('.') && clean.length > 3) clean else "video_${System.currentTimeMillis()}.$ext"
    }
}
