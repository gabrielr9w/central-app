package com.central.app.ui

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import java.util.Locale

/** Página padrão de uma ferramenta: rolável, com espaçamento. */
@Composable
fun ToolPage(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content,
    )
}

/** Campo de texto padrão. Use type = KeyboardType.Decimal para números. */
@Composable
fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    type: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    minLines: Int = 1,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = minLines,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = type),
    )
}

@Composable
fun NumField(value: String, onChange: (String) -> Unit, label: String) =
    Field(value, onChange, label, KeyboardType.Decimal)

/** Linha de "chips" para escolher uma opção entre várias. */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun Chooser(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEachIndexed { i, name ->
            FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(name) })
        }
    }
}

/** Cartão de resultado, com botão opcional de copiar. */
@Composable
fun ResultCard(
    text: String,
    copyable: Boolean = false,
    style: TextStyle = MaterialTheme.typography.titleLarge,
) {
    val clipboard = LocalClipboardManager.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text, style = style)
            if (copyable && text.isNotEmpty()) {
                TextButton(onClick = { clipboard.setText(AnnotatedString(text)) }) { Text("Copiar") }
            }
        }
    }
}

/** Formata número em português (vírgula decimal, sem zeros sobrando). */
fun fmt(v: Double, digits: Int = 2): String {
    if (v.isNaN() || v.isInfinite()) return "—"
    var s = String.format(Locale.US, "%." + digits + "f", v)
    if (s.contains('.')) s = s.trimEnd('0').trimEnd('.')
    if (s == "-0") s = "0"
    return s.replace('.', ',')
}

/** Lê número aceitando vírgula ou ponto. */
fun String.toNum(): Double? = trim().replace(',', '.').toDoubleOrNull()

/** Guarda pequenas coisas no celular (notas, tarefas, contador). */
object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("central", Context.MODE_PRIVATE)

    fun getList(c: Context, key: String): List<String> {
        val raw = prefs(c).getString(key, null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            List(a.length()) { a.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun putList(c: Context, key: String, items: List<String>) {
        prefs(c).edit().putString(key, JSONArray(items).toString()).apply()
    }

    fun getInt(c: Context, key: String, default: Int = 0): Int = prefs(c).getInt(key, default)

    fun putInt(c: Context, key: String, value: Int) {
        prefs(c).edit().putInt(key, value).apply()
    }
}
