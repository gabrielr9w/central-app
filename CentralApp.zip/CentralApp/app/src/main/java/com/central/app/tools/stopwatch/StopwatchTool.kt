package com.central.app.tools.stopwatch

import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.central.app.core.Tool
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import kotlinx.coroutines.delay

private fun fmtTime(ms: Long): String {
    val cs = (ms / 10) % 100
    val s = (ms / 1000) % 60
    val m = ms / 60000
    return "%02d:%02d.%02d".format(m, s, cs)
}

object StopwatchTool : Tool {
    override val id = "stopwatch"
    override val title = "Cronômetro"
    override val description = "Com voltas."
    override val emoji = "⏱️"

    @Composable
    override fun Content() {
        var running by remember { mutableStateOf(false) }
        var elapsed by remember { mutableLongStateOf(0L) }
        val laps = remember { mutableStateListOf<Long>() }

        LaunchedEffect(running) {
            if (running) {
                val base = elapsed
                val start = SystemClock.elapsedRealtime()
                while (true) {
                    elapsed = base + (SystemClock.elapsedRealtime() - start)
                    delay(30)
                }
            }
        }

        ToolPage {
            ResultCard(fmtTime(elapsed), style = androidx.compose.material3.MaterialTheme.typography.displayMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { running = !running }) { Text(if (running) "Pausar" else "Iniciar", fontSize = 16.sp) }
                OutlinedButton(onClick = { if (running) laps.add(elapsed) }, enabled = running) { Text("Volta") }
                OutlinedButton(onClick = {
                    running = false
                    elapsed = 0L
                    laps.clear()
                }) { Text("Zerar") }
            }
            laps.forEachIndexed { i, t ->
                val previous = if (i == 0) 0L else laps[i - 1]
                ResultCard(
                    "Volta ${i + 1}: ${fmtTime(t)}  (+${fmtTime(t - previous)})",
                    style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}
