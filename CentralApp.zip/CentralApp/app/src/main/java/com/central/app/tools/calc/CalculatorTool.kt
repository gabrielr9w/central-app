package com.central.app.tools.calc

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.central.app.core.Tool
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import com.central.app.ui.fmt

object CalculatorTool : Tool {
    override val id = "calc"
    override val title = "Calculadora"
    override val description = "Contas com parênteses, potência e %."
    override val emoji = "🧮"

    @Composable
    override fun Content() {
        var expr by remember { mutableStateOf("") }
        val result = remember(expr) {
            if (expr.isBlank()) "" else try {
                fmt(Calc.eval(expr), 8)
            } catch (e: Exception) {
                "…"
            }
        }

        val rows = listOf(
            listOf("C", "⌫", "(", ")"),
            listOf("7", "8", "9", "÷"),
            listOf("4", "5", "6", "×"),
            listOf("1", "2", "3", "-"),
            listOf("0", ",", "%", "+"),
            listOf("^"),
        )

        ToolPage {
            ResultCard(text = if (expr.isEmpty()) "0" else expr, style = androidx.compose.material3.MaterialTheme.typography.headlineSmall)
            ResultCard(text = "= $result")
            rows.forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { key ->
                        FilledTonalButton(
                            onClick = {
                                expr = when (key) {
                                    "C" -> ""
                                    "⌫" -> expr.dropLast(1)
                                    else -> expr + key
                                }
                            },
                            modifier = Modifier.weight(1f),
                        ) { Text(key, fontSize = 20.sp) }
                    }
                }
            }
        }
    }
}

/** Avaliador simples de expressões: + - × ÷ ^ ( ) e %. */
object Calc {
    fun eval(src: String): Double {
        val clean = src.replace(" ", "")
            .replace(',', '.')
            .replace('×', '*')
            .replace('÷', '/')
        val p = Parser(clean)
        val v = p.expr()
        if (p.pos != clean.length) throw IllegalArgumentException("Expressão inválida")
        return v
    }

    private class Parser(val s: String) {
        var pos = 0

        fun peek(): Char = if (pos < s.length) s[pos] else '\u0000'

        fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') {
                val op = s[pos++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        fun term(): Double {
            var v = power()
            while (peek() == '*' || peek() == '/') {
                val op = s[pos++]
                val r = power()
                v = if (op == '*') v * r else v / r
            }
            return v
        }

        fun power(): Double {
            val base = unary()
            if (peek() == '^') {
                pos++
                return Math.pow(base, power())
            }
            return base
        }

        fun unary(): Double {
            if (peek() == '-') {
                pos++
                return -unary()
            }
            if (peek() == '+') {
                pos++
                return unary()
            }
            return postfix()
        }

        fun postfix(): Double {
            var v = atom()
            while (peek() == '%') {
                pos++
                v /= 100.0
            }
            return v
        }

        fun atom(): Double {
            if (peek() == '(') {
                pos++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("Parêntese aberto")
                pos++
                return v
            }
            val start = pos
            while (peek().isDigit() || peek() == '.') pos++
            if (start == pos) throw IllegalArgumentException("Expressão inválida")
            return s.substring(start, pos).toDouble()
        }
    }
}
