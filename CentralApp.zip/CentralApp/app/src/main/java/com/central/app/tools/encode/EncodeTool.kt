package com.central.app.tools.encode

import android.util.Base64
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.central.app.core.Tool
import com.central.app.ui.Chooser
import com.central.app.ui.Field
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import java.net.URLDecoder
import java.net.URLEncoder

object EncodeTool : Tool {
    override val id = "encode"
    override val title = "Codificar"
    override val description = "Base64 e URL, para codificar e decodificar."
    override val emoji = "🧬"

    private val modes = listOf("Base64 codificar", "Base64 decodificar", "URL codificar", "URL decodificar")

    private fun run(mode: Int, input: String): String = try {
        when (mode) {
            0 -> Base64.encodeToString(input.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            1 -> String(Base64.decode(input.trim(), Base64.DEFAULT), Charsets.UTF_8)
            2 -> URLEncoder.encode(input, "UTF-8")
            else -> URLDecoder.decode(input, "UTF-8")
        }
    } catch (e: Exception) {
        "Texto inválido para essa operação"
    }

    @Composable
    override fun Content() {
        var mode by remember { mutableIntStateOf(0) }
        var input by remember { mutableStateOf("") }

        ToolPage {
            Chooser(modes, mode) { mode = it }
            Field(input, { input = it }, "Texto", singleLine = false, minLines = 4)
            if (input.isNotEmpty()) {
                ResultCard(run(mode, input), copyable = true, style = androidx.compose.material3.MaterialTheme.typography.bodyLarge)
            }
        }
    }
}
