package com.central.app.tools.notes

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.central.app.core.Tool
import com.central.app.ui.Field
import com.central.app.ui.Store
import com.central.app.ui.ToolPage

object NotesTool : Tool {
    override val id = "notes"
    override val title = "Notas"
    override val description = "Anotações rápidas salvas no celular."
    override val emoji = "📝"

    private const val KEY = "notes"

    @Composable
    override fun Content() {
        val context = LocalContext.current
        val notes = remember { mutableStateListOf<String>().apply { addAll(Store.getList(context, KEY)) } }
        var draft by remember { mutableStateOf("") }

        ToolPage {
            Field(draft, { draft = it }, "Nova nota", singleLine = false, minLines = 3)
            Button(
                onClick = {
                    if (draft.isNotBlank()) {
                        notes.add(0, draft.trim())
                        draft = ""
                        Store.putList(context, KEY, notes.toList())
                    }
                },
                enabled = draft.isNotBlank(),
            ) { Text("Salvar nota") }

            notes.forEachIndexed { i, note ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(note)
                        Row {
                            TextButton(onClick = {
                                notes.removeAt(i)
                                Store.putList(context, KEY, notes.toList())
                            }) { Text("Apagar") }
                        }
                    }
                }
            }
        }
    }
}
