package com.central.app.tools.random

import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.KeyboardType
import com.central.app.core.Tool
import com.central.app.ui.Chooser
import com.central.app.ui.Field
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage

object RandomTool : Tool {
    override val id = "random"
    override val title = "Sorteio"
    override val description = "Número, dado, moeda e sorteio de nomes."
    override val emoji = "🎲"

    private val modes = listOf("Número", "Dado", "Moeda", "Nomes")

    @Composable
    override fun Content() {
        var mode by remember { mutableIntStateOf(0) }
        var min by remember { mutableStateOf("1") }
        var max by remember { mutableStateOf("100") }
        var sides by remember { mutableStateOf("6") }
        var qty by remember { mutableStateOf("1") }
        var names by remember { mutableStateOf("") }
        var result by remember { mutableStateOf("") }

        ToolPage {
            Chooser(modes, mode) {
                mode = it
                result = ""
            }
            when (mode) {
                0 -> {
                    Field(min, { min = it }, "Mínimo")
                    Field(max, { max = it }, "Máximo")
                }
                1 -> {
                    Field(sides, { sides = it }, "Lados do dado", KeyboardType.Number)
                    Field(qty, { qty = it }, "Quantidade de dados", KeyboardType.Number)
                }
                3 -> Field(names, { names = it }, "Um nome por linha", singleLine = false, minLines = 4)
            }
            Button(onClick = {
                result = when (mode) {
                    0 -> {
                        val a = min.trim().toLongOrNull()
                        val b = max.trim().toLongOrNull()
                        if (a == null || b == null || a > b) {
                            "Confira o mínimo e o máximo"
                        } else {
                            kotlin.random.Random.nextLong(a, b + 1).toString()
                        }
                    }
                    1 -> {
                        val s = sides.trim().toIntOrNull() ?: 0
                        val q = (qty.trim().toIntOrNull() ?: 0).coerceAtMost(50)
                        if (s < 2 || q < 1) {
                            "Confira os lados e a quantidade"
                        } else {
                            val rolls = List(q) { kotlin.random.Random.nextInt(1, s + 1) }
                            if (q == 1) rolls[0].toString() else rolls.joinToString(" + ") + " = " + rolls.sum()
                        }
                    }
                    2 -> if (kotlin.random.Random.nextBoolean()) "Cara" else "Coroa"
                    else -> {
                        val list = names.lines().map { it.trim() }.filter { it.isNotEmpty() }
                        if (list.isEmpty()) "Digite pelo menos um nome" else list.random()
                    }
                }
            }) { Text(if (mode == 2) "Jogar" else "Sortear") }
            if (result.isNotEmpty()) ResultCard(result, copyable = true)
        }
    }
}
