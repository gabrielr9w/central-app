package com.central.app.tools.counter

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.central.app.core.Tool
import com.central.app.ui.ResultCard
import com.central.app.ui.Store
import com.central.app.ui.ToolPage

object CounterTool : Tool {
    override val id = "counter"
    override val title = "Contador"
    override val description = "Conta pessoas, itens, voltas. Fica salvo."
    override val emoji = "🔢"

    private const val KEY = "counter"

    @Composable
    override fun Content() {
        val context = LocalContext.current
        var count by remember { mutableIntStateOf(Store.getInt(context, KEY)) }

        fun update(v: Int) {
            count = v
            Store.putInt(context, KEY, v)
        }

        ToolPage {
            ResultCard(count.toString(), style = androidx.compose.material3.MaterialTheme.typography.displayLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { update(count + 1) }) { Text("+1", fontSize = 20.sp) }
                OutlinedButton(onClick = { update(count - 1) }) { Text("−1", fontSize = 20.sp) }
                OutlinedButton(onClick = { update(0) }) { Text("Zerar") }
            }
        }
    }
}
