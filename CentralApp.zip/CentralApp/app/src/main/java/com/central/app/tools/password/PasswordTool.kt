package com.central.app.tools.password

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.central.app.core.Tool
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import java.security.SecureRandom

private const val UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ"
private const val LOWER = "abcdefghijkmnopqrstuvwxyz"
private const val DIGITS = "23456789"
private const val SYMBOLS = "!@#$%&*?-_+="

private fun generate(length: Int, upper: Boolean, digits: Boolean, symbols: Boolean): String {
    val rnd = SecureRandom()
    val pools = mutableListOf(LOWER)
    if (upper) pools += UPPER
    if (digits) pools += DIGITS
    if (symbols) pools += SYMBOLS
    val all = pools.joinToString("")
    val chars = mutableListOf<Char>()
    // garante ao menos um caractere de cada grupo escolhido
    pools.forEach { chars += it[rnd.nextInt(it.length)] }
    while (chars.size < length) chars += all[rnd.nextInt(all.length)]
    chars.shuffle(rnd)
    return chars.take(length).joinToString("")
}

object PasswordTool : Tool {
    override val id = "password"
    override val title = "Gerar senha"
    override val description = "Senhas fortes e aleatórias."
    override val emoji = "🔐"

    @Composable
    override fun Content() {
        var length by remember { mutableFloatStateOf(16f) }
        var upper by remember { mutableStateOf(true) }
        var digits by remember { mutableStateOf(true) }
        var symbols by remember { mutableStateOf(true) }
        var password by remember { mutableStateOf("") }

        ToolPage {
            Text("Tamanho: ${length.toInt()}")
            Slider(value = length, onValueChange = { length = it }, valueRange = 6f..40f, steps = 33)
            ToggleRow("Letras maiúsculas", upper) { upper = it }
            ToggleRow("Números", digits) { digits = it }
            ToggleRow("Símbolos", symbols) { symbols = it }
            Button(onClick = { password = generate(length.toInt(), upper, digits, symbols) }) { Text("Gerar") }
            if (password.isNotEmpty()) ResultCard(password, copyable = true)
        }
    }

    @Composable
    private fun ToggleRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label)
            Switch(checked = value, onCheckedChange = onChange)
        }
    }
}
