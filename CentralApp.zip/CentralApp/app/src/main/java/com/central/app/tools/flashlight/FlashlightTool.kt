package com.central.app.tools.flashlight

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.central.app.core.Tool
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage

object FlashlightTool : Tool {
    override val id = "flashlight"
    override val title = "Lanterna"
    override val description = "Liga e desliga o flash do celular."
    override val emoji = "🔦"

    @Composable
    override fun Content() {
        val context = LocalContext.current
        val manager = remember { context.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
        val cameraId = remember {
            runCatching {
                manager.cameraIdList.firstOrNull { id ->
                    val c = manager.getCameraCharacteristics(id)
                    c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                        c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                }
            }.getOrNull()
        }
        var on by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }

        // Desliga a lanterna ao sair da tela.
        DisposableEffect(Unit) {
            onDispose {
                runCatching { cameraId?.let { manager.setTorchMode(it, false) } }
            }
        }

        ToolPage {
            if (cameraId == null) {
                ResultCard("Este aparelho não tem flash disponível.")
            } else {
                ResultCard(if (on) "Ligada" else "Desligada")
                Button(onClick = {
                    try {
                        manager.setTorchMode(cameraId, !on)
                        on = !on
                        error = null
                    } catch (e: Exception) {
                        error = "Não consegui acessar o flash: ${e.message}"
                    }
                }) { Text(if (on) "Desligar" else "Ligar") }
                error?.let { Text(it) }
            }
        }
    }
}
