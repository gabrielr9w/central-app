package com.central.app.tools.bases

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.central.app.core.Tool
import com.central.app.ui.Chooser
import com.central.app.ui.Field
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage

object BasesTool : Tool {
    override val id = "bases"
    override val title = "Bases numéricas"
    override val description = "Binário, octal, decimal e hexadecimal."
    override val emoji = "💾"

    private val names = listOf("Binário", "Octal", "Decimal", "Hexadecimal")
    private val radixes = listOf(2, 8, 10, 16)

    @Composable
    override fun Content() {
        var base by remember { mutableIntStateOf(2) }
        var input by remember { mutableStateOf("") }

        val value = input.trim().toLongOrNull(radixes[base])

        ToolPage {
            Chooser(names, base) { base = it }
            Field(input, { input = it }, "Número em ${names[base].lowercase()}")
            if (input.isNotBlank()) {
                if (value == null) {
                    ResultCard("Número inválido para essa base")
                } else {
                    ResultCard(
                        "Binário: ${java.lang.Long.toString(value, 2)}\n" +
                            "Octal: ${java.lang.Long.toString(value, 8)}\n" +
                            "Decimal: $value\n" +
                            "Hexadecimal: ${java.lang.Long.toString(value, 16).uppercase()}",
                        copyable = false,
                        style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                    )
                }
            }
        }
    }
}
