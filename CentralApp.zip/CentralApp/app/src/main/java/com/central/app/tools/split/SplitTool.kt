package com.central.app.tools.split

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.KeyboardType
import com.central.app.core.Tool
import com.central.app.ui.Field
import com.central.app.ui.NumField
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import com.central.app.ui.fmt
import com.central.app.ui.toNum

object SplitTool : Tool {
    override val id = "split"
    override val title = "Dividir conta"
    override val description = "Total, gorjeta e valor por pessoa."
    override val emoji = "🍽️"

    @Composable
    override fun Content() {
        var total by remember { mutableStateOf("") }
        var people by remember { mutableStateOf("2") }
        var tip by remember { mutableStateOf("10") }

        val t = total.toNum()
        val n = people.trim().toIntOrNull()
        val g = tip.toNum() ?: 0.0

        ToolPage {
            NumField(total, { total = it }, "Total da conta (R$)")
            Field(people, { people = it }, "Número de pessoas", KeyboardType.Number)
            NumField(tip, { tip = it }, "Gorjeta (%)")
            if (t != null && n != null && n > 0) {
                val withTip = t * (1 + g / 100.0)
                ResultCard("Por pessoa: R$ ${fmt(withTip / n)}")
                ResultCard(
                    "Total com gorjeta: R$ ${fmt(withTip)}\nGorjeta: R$ ${fmt(withTip - t)}",
                    style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}
