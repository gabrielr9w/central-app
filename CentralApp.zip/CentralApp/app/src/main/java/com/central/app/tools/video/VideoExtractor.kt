package com.central.app.tools.video

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

data class VideoCandidate(
    val url: String,
    /** "MP4", "WEBM" ou "HLS" (streaming em pedaços, ainda não suportado). */
    val type: String,
    val sizeBytes: Long?,
) {
    val isStream: Boolean get() = type == "HLS"
}

/**
 * Recebe o link colado, abre a página e procura links de vídeo:
 * meta tags (og:video), <video>/<source> e URLs .mp4/.webm/.m3u8 soltas no HTML/JSON.
 * Se o próprio link já for um vídeo, devolve ele direto.
 */
object VideoExtractor {
    const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0 Mobile Safari/537.36"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val metaVideo = Regex(
        """<meta[^>]+(?:property|name)\s*=\s*["'](?:og:video(?::url|:secure_url)?|twitter:player:stream)["'][^>]*?content\s*=\s*["']([^"']+)["']""",
        RegexOption.IGNORE_CASE,
    )
    private val metaVideoRev = Regex(
        """<meta[^>]+content\s*=\s*["']([^"']+)["'][^>]*?(?:property|name)\s*=\s*["'](?:og:video(?::url|:secure_url)?|twitter:player:stream)["']""",
        RegexOption.IGNORE_CASE,
    )
    private val tagSrc = Regex(
        """<(?:video|source)[^>]+\ssrc\s*=\s*["']([^"']+)["']""",
        RegexOption.IGNORE_CASE,
    )
    private val rawLink = Regex(
        """https?://[^\s"'<>\\]+?\.(?:mp4|webm|m4v|mov|m3u8)(?:\?[^\s"'<>\\]*)?""",
        RegexOption.IGNORE_CASE,
    )

    suspend fun find(input: String): List<VideoCandidate> = withContext(Dispatchers.IO) {
        val pageUrl = normalize(input) ?: throw IllegalArgumentException("Link inválido")
        val request = Request.Builder().url(pageUrl).header("User-Agent", USER_AGENT).build()

        client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("O site respondeu com erro ${resp.code}")

            val contentType = resp.header("Content-Type").orEmpty().lowercase()
            val finalUrl = resp.request.url

            // O link já é o vídeo.
            if (contentType.startsWith("video/") || contentType.contains("mpegurl")) {
                val size = resp.header("Content-Length")?.toLongOrNull()
                return@withContext listOf(
                    VideoCandidate(finalUrl.toString(), typeOf(finalUrl.toString(), contentType), size),
                )
            }

            val html = resp.peekBody(5_000_000).string()
            collect(html, finalUrl)
        }
    }

    private fun normalize(input: String): HttpUrl? {
        val text = input.trim()
        if (text.isEmpty()) return null
        val withScheme = if (text.startsWith("http://") || text.startsWith("https://")) text else "https://$text"
        return withScheme.toHttpUrlOrNull()
    }

    private fun collect(html: String, base: HttpUrl): List<VideoCandidate> {
        val text = html
            .replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("&amp;", "&")

        val found = LinkedHashSet<String>()
        for (rx in listOf(metaVideo, metaVideoRev, tagSrc, rawLink)) {
            for (m in rx.findAll(text)) {
                val value = (if (m.groupValues.size > 1) m.groupValues[1] else m.value).trim()
                base.resolve(value)?.let { found += it.toString() }
            }
        }

        val result = mutableListOf<VideoCandidate>()
        for (url in found.take(12)) {
            val extType = typeFromExtension(url)
            val head = head(url)
            when {
                extType != null -> result += VideoCandidate(url, extType, head?.second)
                head != null && head.first.startsWith("video/") ->
                    result += VideoCandidate(url, typeOf(url, head.first), head.second)
            }
        }
        return result.sortedBy { if (it.isStream) 1 else 0 }
    }

    /** Devolve (Content-Type, tamanho) ou null se o servidor não respondeu. */
    private fun head(url: String): Pair<String, Long?>? = try {
        val req = Request.Builder().url(url).head().header("User-Agent", USER_AGENT).build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) {
                null
            } else {
                Pair(r.header("Content-Type").orEmpty().lowercase(), r.header("Content-Length")?.toLongOrNull())
            }
        }
    } catch (e: Exception) {
        null
    }

    private fun typeFromExtension(url: String): String? {
        val path = url.substringBefore('?').lowercase()
        return when {
            path.endsWith(".mp4") || path.endsWith(".m4v") || path.endsWith(".mov") -> "MP4"
            path.endsWith(".webm") -> "WEBM"
            path.endsWith(".m3u8") -> "HLS"
            else -> null
        }
    }

    private fun typeOf(url: String, contentType: String): String =
        typeFromExtension(url) ?: when {
            contentType.contains("webm") -> "WEBM"
            contentType.contains("mpegurl") -> "HLS"
            else -> "MP4"
        }
}
