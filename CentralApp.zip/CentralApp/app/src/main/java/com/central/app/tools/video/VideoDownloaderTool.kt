package com.central.app.tools.video

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.central.app.core.IncomingLink
import com.central.app.core.Tool
import kotlinx.coroutines.launch

object VideoDownloaderTool : Tool {
    override val id = "video"
    override val title = "Baixar vídeo"
    override val description = "Cole o link de uma página e baixe o vídeo dela."
    override val emoji = "⬇️"

    @Composable
    override fun Content() {
        VideoDownloaderScreen()
    }
}

@Composable
private fun VideoDownloaderScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var link by rememberSaveable { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var results by remember { mutableStateOf<List<VideoCandidate>>(emptyList()) }

    fun search() {
        val target = link.trim()
        if (target.isEmpty() || loading) return
        scope.launch {
            loading = true
            message = null
            results = emptyList()
            try {
                results = VideoExtractor.find(target)
                if (results.isEmpty()) {
                    message = "Não encontrei nenhum vídeo baixável nessa página. " +
                        "Sites que protegem o vídeo (YouTube, Netflix etc.) não funcionam por aqui."
                }
            } catch (e: Exception) {
                message = "Erro: ${e.message ?: "não consegui abrir o link"}"
            } finally {
                loading = false
            }
        }
    }

    // Link vindo do "Compartilhar" do navegador: preenche e já busca.
    LaunchedEffect(IncomingLink.url) {
        IncomingLink.url?.let {
            link = it
            IncomingLink.url = null
            search()
        }
    }

    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        OutlinedTextField(
            value = link,
            onValueChange = { link = it },
            label = { Text("Link da página ou do vídeo") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { search() }),
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                clipboard.getText()?.text?.let { link = it.trim() }
            }) { Text("Colar") }

            Button(onClick = { search() }, enabled = link.isNotBlank() && !loading) {
                Text("Buscar vídeo")
            }
        }

        if (loading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

        message?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(results, key = { it.url }) { video ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = video.type + (video.sizeBytes?.let { " · ${formatSize(it)}" } ?: ""),
                            style = MaterialTheme.typography.titleSmall,
                        )
                        Text(
                            text = video.url,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (video.isStream) {
                            Text(
                                "Vídeo em streaming (HLS): ainda não suportado.",
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        } else {
                            Button(onClick = {
                                try {
                                    VideoDownloader.enqueue(context, video, link.trim())
                                    Toast.makeText(context, "Download iniciado (pasta Filmes/Central)", Toast.LENGTH_LONG).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Falha ao iniciar: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            }) { Text("Baixar") }
                        }
                    }
                }
            }
        }
    }
}

private fun formatSize(bytes: Long): String = when {
    bytes >= 1_000_000_000 -> "%.1f GB".format(bytes / 1_000_000_000.0)
    bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
    else -> "%d KB".format(bytes / 1000)
}
