package com.central.app.core

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.central.app.tools.video.VideoDownloaderTool

/**
 * Cada função do app é uma "Tool". Para adicionar uma nova:
 * 1. Crie um object que implemente Tool.
 * 2. Registre-o na lista de ToolRegistry abaixo.
 * Ela aparece sozinha na tela inicial.
 */
interface Tool {
    val id: String
    val title: String
    val description: String
    val emoji: String

    @Composable
    fun Content()
}

object ToolRegistry {
    val tools: List<Tool> = listOf(
        VideoDownloaderTool,
        // Próximas funções entram aqui.
    )
}

/** Link recebido via "Compartilhar" de outro app (navegador, etc.). */
object IncomingLink {
    var url by mutableStateOf<String?>(null)
}
