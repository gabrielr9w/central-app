package com.central.app.core

import androidx.compose.runtime.Composable
import com.central.app.tools.bases.BasesTool
import com.central.app.tools.bmi.BmiTool
import com.central.app.tools.calc.CalculatorTool
import com.central.app.tools.colors.ColorsTool
import com.central.app.tools.counter.CounterTool
import com.central.app.tools.dates.DatesTool
import com.central.app.tools.encode.EncodeTool
import com.central.app.tools.flashlight.FlashlightTool
import com.central.app.tools.fuel.FuelTool
import com.central.app.tools.notes.NotesTool
import com.central.app.tools.password.PasswordTool
import com.central.app.tools.percent.PercentTool
import com.central.app.tools.random.RandomTool
import com.central.app.tools.split.SplitTool
import com.central.app.tools.stopwatch.StopwatchTool
import com.central.app.tools.textcount.TextCountTool
import com.central.app.tools.textools.TextToolsTool
import com.central.app.tools.timer.TimerTool
import com.central.app.tools.todo.TodoTool
import com.central.app.tools.units.UnitsTool

/**
 * Cada função do app é uma "Tool". Para adicionar uma nova:
 * 1. Crie um object que implemente Tool.
 * 2. Registre-o na lista de ToolRegistry abaixo.
 * Ela aparece sozinha na tela inicial.
 */
interface Tool {
    val id: String
    val title: String
    val description: String
    val emoji: String

    @Composable
    fun Content()
}

object ToolRegistry {
    val tools: List<Tool> = listOf(
        CalculatorTool,
        UnitsTool,
        PercentTool,
        SplitTool,
        FuelTool,
        BmiTool,
        DatesTool,
        StopwatchTool,
        TimerTool,
        NotesTool,
        TodoTool,
        CounterTool,
        PasswordTool,
        RandomTool,
        TextCountTool,
        TextToolsTool,
        EncodeTool,
        BasesTool,
        ColorsTool,
        FlashlightTool,
    )
}
