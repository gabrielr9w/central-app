package com.central.app.tools.fuel

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.central.app.core.Tool
import com.central.app.ui.NumField
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import com.central.app.ui.fmt
import com.central.app.ui.toNum

object FuelTool : Tool {
    override val id = "fuel"
    override val title = "Álcool ou gasolina"
    override val description = "Descubra qual compensa abastecer."
    override val emoji = "⛽"

    @Composable
    override fun Content() {
        var alcohol by remember { mutableStateOf("") }
        var gasoline by remember { mutableStateOf("") }

        val a = alcohol.toNum()
        val g = gasoline.toNum()

        ToolPage {
            NumField(alcohol, { alcohol = it }, "Preço do álcool/etanol (R$/L)")
            NumField(gasoline, { gasoline = it }, "Preço da gasolina (R$/L)")
            if (a != null && g != null && g > 0.0) {
                val ratio = a / g * 100.0
                val best = if (ratio <= 70.0) "Compensa abastecer com ÁLCOOL" else "Compensa abastecer com GASOLINA"
                ResultCard(best)
                ResultCard(
                    "O álcool custa ${fmt(ratio, 1)}% do preço da gasolina.\n" +
                        "Regra geral: até 70% vale mais o álcool (pode variar conforme o carro).",
                    style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}
