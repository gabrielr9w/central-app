package com.central.app.tools.textools

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.central.app.core.Tool
import com.central.app.ui.Chooser
import com.central.app.ui.Field
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import java.text.Normalizer

private val operations: List<Pair<String, (String) -> String>> = listOf(
    "MAIÚSCULAS" to { s: String -> s.uppercase() },
    "minúsculas" to { s: String -> s.lowercase() },
    "Título" to { s: String ->
        s.split(" ").joinToString(" ") { w -> w.lowercase().replaceFirstChar { c -> c.uppercase() } }
    },
    "Inverter texto" to { s: String -> s.reversed() },
    "Ordenar linhas" to { s: String -> s.lines().sorted().joinToString("\n") },
    "Remover linhas repetidas" to { s: String -> s.lines().distinct().joinToString("\n") },
    "Remover espaços extras" to { s: String ->
        s.lines().joinToString("\n") { l -> l.replace(Regex("[ \\t]+"), " ").trim() }
    },
    "Remover acentos" to { s: String ->
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    },
)

object TextToolsTool : Tool {
    override val id = "textools"
    override val title = "Ferramentas de texto"
    override val description = "Maiúsculas, ordenar, limpar e mais."
    override val emoji = "✂️"

    @Composable
    override fun Content() {
        var text by remember { mutableStateOf("") }
        var op by remember { mutableIntStateOf(0) }

        ToolPage {
            Field(text, { text = it }, "Texto", singleLine = false, minLines = 5)
            Chooser(operations.map { it.first }, op) { op = it }
            if (text.isNotEmpty()) {
                ResultCard(
                    operations[op].second(text),
                    copyable = true,
                    style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}
