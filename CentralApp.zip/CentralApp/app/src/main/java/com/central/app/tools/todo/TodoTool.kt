package com.central.app.tools.todo

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.Button
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import com.central.app.core.Tool
import com.central.app.ui.Field
import com.central.app.ui.Store
import com.central.app.ui.ToolPage

/** Cada tarefa é guardada como "1|texto" (feita) ou "0|texto" (pendente). */
object TodoTool : Tool {
    override val id = "todo"
    override val title = "Tarefas"
    override val description = "Lista de afazeres com checkbox."
    override val emoji = "✅"

    private const val KEY = "todo"

    @Composable
    override fun Content() {
        val context = LocalContext.current
        val items = remember { mutableStateListOf<String>().apply { addAll(Store.getList(context, KEY)) } }
        var draft by remember { mutableStateOf("") }

        fun persist() = Store.putList(context, KEY, items.toList())

        ToolPage {
            Field(draft, { draft = it }, "Nova tarefa")
            Button(
                onClick = {
                    if (draft.isNotBlank()) {
                        items.add("0|" + draft.trim())
                        draft = ""
                        persist()
                    }
                },
                enabled = draft.isNotBlank(),
            ) { Text("Adicionar") }

            items.forEachIndexed { i, raw ->
                val done = raw.startsWith("1|")
                val text = raw.drop(2)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Checkbox(checked = done, onCheckedChange = {
                            items[i] = (if (it) "1|" else "0|") + text
                            persist()
                        })
                        Text(text, textDecoration = if (done) TextDecoration.LineThrough else null)
                    }
                    TextButton(onClick = {
                        items.removeAt(i)
                        persist()
                    }) { Text("Apagar") }
                }
            }

            if (items.any { it.startsWith("1|") }) {
                TextButton(onClick = {
                    items.removeAll { it.startsWith("1|") }
                    persist()
                }) { Text("Limpar concluídas") }
            }
        }
    }
}
