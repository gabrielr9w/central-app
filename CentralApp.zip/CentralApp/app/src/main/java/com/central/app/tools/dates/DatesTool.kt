package com.central.app.tools.dates

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.central.app.core.Tool
import com.central.app.ui.Chooser
import com.central.app.ui.Field
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import java.time.LocalDate
import java.time.Period
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

private val FORMAT: DateTimeFormatter =
    DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT)

private fun parse(s: String): LocalDate? = try {
    LocalDate.parse(s.trim(), FORMAT)
} catch (e: Exception) {
    null
}

private fun weekday(d: LocalDate): String =
    d.dayOfWeek.getDisplayName(TextStyle.FULL, Locale("pt", "BR"))

object DatesTool : Tool {
    override val id = "dates"
    override val title = "Datas"
    override val description = "Diferença entre datas, somar dias e idade."
    override val emoji = "📅"

    private val modes = listOf("Diferença", "Somar dias", "Idade")

    @Composable
    override fun Content() {
        val today = remember { LocalDate.now().format(FORMAT) }
        var mode by remember { mutableIntStateOf(0) }
        var a by remember { mutableStateOf(today) }
        var b by remember { mutableStateOf(today) }
        var days by remember { mutableStateOf("30") }

        val da = parse(a)
        val db = parse(b)

        ToolPage {
            Chooser(modes, mode) { mode = it }
            when (mode) {
                0 -> {
                    Field(a, { a = it }, "Data inicial (dd/mm/aaaa)")
                    Field(b, { b = it }, "Data final (dd/mm/aaaa)")
                    if (da != null && db != null) {
                        val total = ChronoUnit.DAYS.between(da, db)
                        val first = if (da.isBefore(db)) da else db
                        val last = if (da.isBefore(db)) db else da
                        val p = Period.between(first, last)
                        ResultCard("${Math.abs(total)} dias")
                        ResultCard(
                            "${p.years} anos, ${p.months} meses e ${p.days} dias",
                            style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                        )
                    }
                }
                1 -> {
                    Field(a, { a = it }, "Data (dd/mm/aaaa)")
                    Field(days, { days = it }, "Dias a somar (use - para subtrair)")
                    val n = days.trim().toLongOrNull()
                    if (da != null && n != null) {
                        val r = da.plusDays(n)
                        ResultCard("${r.format(FORMAT)} (${weekday(r)})")
                    }
                }
                else -> {
                    Field(a, { a = it }, "Data de nascimento (dd/mm/aaaa)")
                    val now = LocalDate.now()
                    if (da != null && !da.isAfter(now)) {
                        val p = Period.between(da, now)
                        ResultCard("${p.years} anos, ${p.months} meses e ${p.days} dias")
                        ResultCard(
                            "Dias vividos: ${ChronoUnit.DAYS.between(da, now)}",
                            style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                        )
                    }
                }
            }
        }
    }
}
