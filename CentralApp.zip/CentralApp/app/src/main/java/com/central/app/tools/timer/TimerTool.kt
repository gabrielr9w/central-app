package com.central.app.tools.timer

import android.content.Context
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.central.app.core.Tool
import com.central.app.ui.Field
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import kotlinx.coroutines.delay

private fun vibrate(context: Context) {
    try {
        val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        v?.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (e: Exception) {
        // sem vibração disponível, tudo bem
    }
}

private fun clock(ms: Long): String {
    val total = (ms + 999) / 1000
    return "%02d:%02d".format(total / 60, total % 60)
}

object TimerTool : Tool {
    override val id = "timer"
    override val title = "Timer"
    override val description = "Contagem regressiva que vibra no fim."
    override val emoji = "⏳"

    @Composable
    override fun Content() {
        val context = LocalContext.current
        var minutes by remember { mutableStateOf("5") }
        var seconds by remember { mutableStateOf("0") }
        var running by remember { mutableStateOf(false) }
        var remaining by remember { mutableLongStateOf(0L) }
        var finished by remember { mutableStateOf(false) }

        LaunchedEffect(running) {
            if (running) {
                val end = SystemClock.elapsedRealtime() + remaining
                while (true) {
                    val left = end - SystemClock.elapsedRealtime()
                    if (left <= 0) {
                        remaining = 0
                        running = false
                        finished = true
                        vibrate(context)
                        break
                    }
                    remaining = left
                    delay(100)
                }
            }
        }

        ToolPage {
            if (remaining == 0L && !running) {
                Field(minutes, { minutes = it }, "Minutos", KeyboardType.Number)
                Field(seconds, { seconds = it }, "Segundos", KeyboardType.Number)
            }
            ResultCard(
                if (finished) "Acabou!" else clock(remaining),
                style = androidx.compose.material3.MaterialTheme.typography.displayMedium,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    if (running) {
                        running = false
                    } else {
                        if (remaining == 0L) {
                            val m = minutes.trim().toLongOrNull() ?: 0L
                            val s = seconds.trim().toLongOrNull() ?: 0L
                            remaining = (m * 60 + s) * 1000
                        }
                        if (remaining > 0L) {
                            finished = false
                            running = true
                        }
                    }
                }) { Text(if (running) "Pausar" else "Iniciar") }
                OutlinedButton(onClick = {
                    running = false
                    remaining = 0L
                    finished = false
                }) { Text("Zerar") }
            }
        }
    }
}
