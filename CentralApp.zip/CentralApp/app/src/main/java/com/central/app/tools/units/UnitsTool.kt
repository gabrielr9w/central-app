package com.central.app.tools.units

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.central.app.core.Tool
import com.central.app.ui.Chooser
import com.central.app.ui.NumField
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage
import com.central.app.ui.fmt
import com.central.app.ui.toNum

private class Un(val name: String, val f: Double)
private class Cat(val name: String, val units: List<Un>)

private val categories = listOf(
    Cat(
        "Comprimento",
        listOf(
            Un("mm", 0.001), Un("cm", 0.01), Un("m", 1.0), Un("km", 1000.0),
            Un("polegada", 0.0254), Un("pé", 0.3048), Un("milha", 1609.344),
        ),
    ),
    Cat(
        "Peso",
        listOf(
            Un("g", 0.001), Un("kg", 1.0), Un("tonelada", 1000.0),
            Un("libra", 0.45359237), Un("onça", 0.028349523),
        ),
    ),
    Cat(
        "Volume",
        listOf(
            Un("ml", 0.001), Un("litro", 1.0), Un("copo (240 ml)", 0.24),
            Un("colher de sopa", 0.015), Un("galão (EUA)", 3.785411784),
        ),
    ),
    Cat(
        "Velocidade",
        listOf(
            Un("m/s", 1.0), Un("km/h", 1.0 / 3.6), Un("mph", 0.44704), Un("nós", 0.514444),
        ),
    ),
    Cat(
        "Temperatura",
        listOf(Un("°C", 0.0), Un("°F", 0.0), Un("K", 0.0)),
    ),
)

private fun convert(cat: Cat, from: Un, to: Un, v: Double): Double {
    if (cat.name == "Temperatura") {
        val c = when (from.name) {
            "°C" -> v
            "°F" -> (v - 32.0) * 5.0 / 9.0
            else -> v - 273.15
        }
        return when (to.name) {
            "°C" -> c
            "°F" -> c * 9.0 / 5.0 + 32.0
            else -> c + 273.15
        }
    }
    return v * from.f / to.f
}

object UnitsTool : Tool {
    override val id = "units"
    override val title = "Conversor"
    override val description = "Comprimento, peso, volume, velocidade e temperatura."
    override val emoji = "📏"

    @Composable
    override fun Content() {
        var catIdx by remember { mutableIntStateOf(0) }
        var fromIdx by remember { mutableIntStateOf(0) }
        var toIdx by remember { mutableIntStateOf(1) }
        var input by remember { mutableStateOf("1") }

        val cat = categories[catIdx]
        val from = cat.units[fromIdx.coerceIn(0, cat.units.lastIndex)]
        val to = cat.units[toIdx.coerceIn(0, cat.units.lastIndex)]
        val value = input.toNum()

        ToolPage {
            Chooser(categories.map { it.name }, catIdx) {
                catIdx = it
                fromIdx = 0
                toIdx = 1
            }
            Text("De")
            Chooser(cat.units.map { it.name }, fromIdx) { fromIdx = it }
            Text("Para")
            Chooser(cat.units.map { it.name }, toIdx) { toIdx = it }
            NumField(input, { input = it }, "Valor")
            if (value != null) {
                ResultCard("${fmt(value, 6)} ${from.name} = ${fmt(convert(cat, from, to, value), 6)} ${to.name}")
            }
        }
    }
}
