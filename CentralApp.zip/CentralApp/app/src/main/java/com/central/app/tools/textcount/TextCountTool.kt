package com.central.app.tools.textcount

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.central.app.core.Tool
import com.central.app.ui.Field
import com.central.app.ui.ResultCard
import com.central.app.ui.ToolPage

object TextCountTool : Tool {
    override val id = "textcount"
    override val title = "Contar texto"
    override val description = "Caracteres, palavras, linhas e tempo de leitura."
    override val emoji = "🔤"

    @Composable
    override fun Content() {
        var text by remember { mutableStateOf("") }

        val chars = text.length
        val noSpaces = text.count { !it.isWhitespace() }
        val words = text.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
        val lines = if (text.isEmpty()) 0 else text.lines().size
        val minutes = words / 200.0

        ToolPage {
            Field(text, { text = it }, "Cole ou digite o texto", singleLine = false, minLines = 6)
            ResultCard(
                "Caracteres: $chars\n" +
                    "Sem espaços: $noSpaces\n" +
                    "Palavras: $words\n" +
                    "Linhas: $lines\n" +
                    "Leitura: ${if (words == 0) "0" else String.format(java.util.Locale.US, "%.1f", minutes).replace('.', ',')} min",
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
            )
        }
    }
}
