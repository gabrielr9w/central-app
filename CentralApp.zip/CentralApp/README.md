# Central

App Android (Kotlin + Jetpack Compose) que reúne várias funções úteis numa tela inicial.

## Como rodar
1. Instale o Android Studio e abra a pasta `CentralApp`.
2. Espere o Gradle sincronizar (ele baixa o que precisa).
3. Conecte o celular (depuração USB) ou use um emulador e clique em Run.
4. Para gerar o APK: Build > Build APK(s).

## Funções
- **Baixar vídeo**: cole o link (ou use Compartilhar > Central no navegador). O app abre a página,
  procura vídeos e baixa o escolhido para a pasta Filmes/Central.

## Limites atuais do baixador
- Funciona com vídeos que aparecem como arquivo (.mp4, .webm) na página.
- Streaming em pedaços (HLS, .m3u8) é detectado mas ainda não baixa.
- Sites que protegem o vídeo (YouTube, Netflix etc.) não funcionam.
- Baixe apenas conteúdo que você tem direito de baixar.

## Como adicionar uma nova função
1. Crie um `object` que implemente `Tool` (veja `tools/video/VideoDownloaderTool.kt`).
2. Registre-o na lista de `ToolRegistry` em `core/Tool.kt`.
Ela aparece sozinha na tela inicial.
