# Central

App Android (Kotlin + Jetpack Compose) que reúne várias funções úteis numa tela inicial.
Funciona sem internet.

## Funções (20)
Calculadora, Conversor de unidades, Porcentagem, Dividir conta, Álcool ou gasolina, IMC, Datas,
Cronômetro, Timer, Notas, Tarefas, Contador, Gerar senha, Sorteio, Contar texto,
Ferramentas de texto, Codificar (Base64/URL), Bases numéricas, Cores, Lanterna.

## Como rodar
1. Abra a pasta `CentralApp` no Android Studio e rode no celular ou emulador.
2. Ou use o GitHub Actions (arquivo `.github/workflows/build.yml` no repositório) para gerar o APK.

## Como adicionar uma nova função
1. Crie um `object` que implemente `Tool` (veja `tools/calc/CalculatorTool.kt`).
2. Registre-o na lista de `ToolRegistry` em `core/Tool.kt`.
Ela aparece sozinha na tela inicial.
Componentes prontos em `ui/Common.kt`: ToolPage, Field, NumField, Chooser, ResultCard, Store.
